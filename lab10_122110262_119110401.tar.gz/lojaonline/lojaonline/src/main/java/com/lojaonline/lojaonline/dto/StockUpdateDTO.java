package com.lojaonline.lojaonline.dto;

public class StockUpdateDTO {
    private int quantity;

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
