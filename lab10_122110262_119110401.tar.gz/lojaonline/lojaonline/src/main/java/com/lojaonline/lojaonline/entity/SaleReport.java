package com.lojaonline.lojaonline.entity;

public class SaleReport {
    
}
