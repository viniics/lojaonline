package com.lojaonline.lojaonline.dto;

import lombok.Data;

@Data
public class PurchaseDTO {
    private Long id;
    private int quantity;
}
