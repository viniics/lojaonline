package com.lojaonline.lojaonline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LojaonlineApplication {

	public static void main(String[] args) {
		SpringApplication.run(LojaonlineApplication.class, args);
	}

}
